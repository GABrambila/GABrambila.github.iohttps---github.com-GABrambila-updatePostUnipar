import React from "react";



function Button(props) {
  

    const buttonStyle = {
        backgraundColor: props.tipo === 'primary'? "green": "red",
        color: props.tippo === 'primary'? "#FFF": "#000",
        padding: "10px 20px",
    };



    return 
        <button style={buttonStyle}>{props.tipo}</button>;
    
}


export default Button; 