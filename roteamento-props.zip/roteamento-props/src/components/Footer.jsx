import React from "react";



const Footer = () => {
    return <footer>Rodapé</footer>;
};


export default Footer; 