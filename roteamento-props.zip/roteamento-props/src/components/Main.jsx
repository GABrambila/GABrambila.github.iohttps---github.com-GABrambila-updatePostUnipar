import React from "react";



const Main = () => {
    return <main></main>;
};


export default Main; 