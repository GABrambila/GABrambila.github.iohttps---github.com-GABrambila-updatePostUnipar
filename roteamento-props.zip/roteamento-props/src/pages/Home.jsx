import React from "react";



const Home = () => {
    return <>Pagina Home</>;
};


export default Home;