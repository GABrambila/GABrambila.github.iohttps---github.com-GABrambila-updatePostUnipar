import React from "react";
import Button from "../components/Button";



const Config = () => {
    return <>Clique no botão a baixo!
        <Button tipo ="primary" />
    </>;
};


export default Config;